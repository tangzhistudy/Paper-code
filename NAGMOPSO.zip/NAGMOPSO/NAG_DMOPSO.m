%******************************************************************************************************************************************
% Coding Author: Zhi Tang
% Last Edited: December 25, 2025
% Email: tangz@stu2023.jnu.edu.cn
% Reference: Dynamic Fleet Configuration and Scheduling for Cross-Border Logistics Based on Improved Multi-Objective Particle Swarm Algorithm in Uncertain Environments
%             (Submitted to Swarm and Evolutionary Computation (Elsevier) Journal)
%******************************************************************************************************************************************
clc
clear
close all
%% ================== 参数设置 ==================
popSize = 500;           % 粒子数
maxIter = 100;          % 最大迭代次数
dim = 10;               % 决策变量维度
lb = zeros(1,dim);      % 下界
ub = ones(1,dim);       % 上界
ArchiveMaxSize = 100;   % 外部档案容量
% 学习因子（线性变化）
c1_max = 2.5; 
c1_min = 0.5;
c2_max = 2.5; 
c2_min = 0.5;
% Logistic混沌参数
mu = 4;
w_min = 0.4; 
w_max = 0.9;
chaos = rand;           % 初始混沌变量
%% ================== 初始化 ==================
for i = 1:popSize
    particle(i).pos = lb + rand(1,dim).*(ub-lb);
    particle(i).vel = zeros(1,dim);
    particle(i).obj = ZDT3(particle(i).pos);
    particle(i).pbest.pos = particle(i).pos;
    particle(i).pbest.obj = particle(i).obj;
end
Archive = UpdateArchive([], particle, ArchiveMaxSize);
%% ================== 主循环 ==================
for iter = 1:maxIter
    % Logistic混沌惯性权重
    chaos = mu * chaos * (1 - chaos);
    w = w_min + (w_max - w_min) * chaos;
    % 学习因子线性变化
    c1 = c1_max - (c1_max - c1_min) * iter / maxIter;
    c2 = c2_min + (c2_max - c2_min) * iter / maxIter;
    % ---------- 非均匀自适应网格 ----------
    Grid = BuildNonUniformGrid(Archive);
    for i = 1:popSize
        leader = SelectLeader(Grid);
        % 速度更新
        particle(i).vel = ...
            w * particle(i).vel ...
            + c1 * rand * (particle(i).pbest.pos - particle(i).pos) ...
            + c2 * rand * (leader.pos - particle(i).pos);
        % 位置更新
        particle(i).pos = particle(i).pos + particle(i).vel;
        particle(i).pos = max(particle(i).pos, lb);
        particle(i).pos = min(particle(i).pos, ub);
        % 目标函数
        particle(i).obj = ZDT3(particle(i).pos);
        % 更新个体最优
        if Dominates(particle(i).obj, particle(i).pbest.obj)
            particle(i).pbest.pos = particle(i).pos;
            particle(i).pbest.obj = particle(i).obj;
        end
    end
    % 更新外部档案
    Archive = UpdateArchive(Archive, particle, ArchiveMaxSize);
    if mod(iter,20)==0
        fprintf('Iter %d | Archive size = %d\n',iter,length(Archive));
    end
end
N = length(Archive);
objs = zeros(N, 2);
for i = 1:N
    objs(i,:) = Archive(i).obj';
end
plot(objs(:,1),objs(:,2),'r.')