%******************************************************************************************************************************************
% Coding Author: Zhi Tang
% Last Edited: December 25, 2025
% Email: tangz@stu2023.jnu.edu.cn
% Reference: Dynamic Fleet Configuration and Scheduling for Cross-Border Logistics Based on Improved Multi-Objective Particle Swarm Algorithm in Uncertain Environments
%             (Submitted to Swarm and Evolutionary Computation (Elsevier) Journal)
%******************************************************************************************************************************************

function crowd = CrowdingDistance(objs)
% -------------------------------------------------
% Crowding distance calculation
% objs: N x M objective matrix
% -------------------------------------------------

[N, M] = size(objs);
crowd = zeros(N,1);

for m = 1:M
    [sorted, idx] = sort(objs(:,m));

    crowd(idx(1))   = inf;
    crowd(idx(end)) = inf;

    fmin = sorted(1);
    fmax = sorted(end);

    if fmax - fmin == 0
        continue;
    end

    for i = 2:N-1
        crowd(idx(i)) = crowd(idx(i)) + ...
            (sorted(i+1) - sorted(i-1)) / (fmax - fmin);
    end
end
end
