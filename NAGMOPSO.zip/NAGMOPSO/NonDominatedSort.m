%******************************************************************************************************************************************
% Coding Author: Zhi Tang
% Last Edited: December 25, 2025
% Email: tangz@stu2023.jnu.edu.cn
% Reference: Dynamic Fleet Configuration and Scheduling for Cross-Border Logistics Based on Improved Multi-Objective Particle Swarm Algorithm in Uncertain Environments
%             (Submitted to Swarm and Evolutionary Computation (Elsevier) Journal)
%******************************************************************************************************************************************

function ND = NonDominatedSort(Pop)
N = length(Pop);
isDominated = false(1, N);

for i = 1:N
    for j = 1:N
        if i ~= j
            if Dominates(Pop(j).obj, Pop(i).obj)
                isDominated(i) = true;
                break;
            end
        end
    end
end

ND = Pop(~isDominated);
end
