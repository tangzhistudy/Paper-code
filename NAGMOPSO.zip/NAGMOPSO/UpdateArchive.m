%******************************************************************************************************************************************
% Coding Author: Zhi Tang
% Last Edited: December 25, 2025
% Email: tangz@stu2023.jnu.edu.cn
% Reference: Dynamic Fleet Configuration and Scheduling for Cross-Border Logistics Based on Improved Multi-Objective Particle Swarm Algorithm in Uncertain Environments
%             (Submitted to Swarm and Evolutionary Computation (Elsevier) Journal)
%******************************************************************************************************************************************

function Archive = UpdateArchive(Archive, particle, MaxSize)
for i = 1:length(particle)
    Archive = [Archive, particle(i)];
end
% 非支配筛选
Archive = NonDominatedSort(Archive);
% 超出容量则删除拥挤区域解
while length(Archive) > MaxSize
    objs = reshape([Archive.obj],2,[])';
    crowd = CrowdingDistance(objs);
    [~,idx] = min(crowd);
    Archive(idx) = [];
end
end
