%******************************************************************************************************************************************
% Coding Author: Zhi Tang
% Last Edited: December 25, 2025
% Email: tangz@stu2023.jnu.edu.cn
% Reference: Dynamic Fleet Configuration and Scheduling for Cross-Border Logistics Based on Improved Multi-Objective Particle Swarm Algorithm in Uncertain Environments
%             (Submitted to Swarm and Evolutionary Computation (Elsevier) Journal)
%******************************************************************************************************************************************

%% NAG
function Grid = BuildNonUniformGrid(Archive)
objs = reshape([Archive.obj],2,[])';
[~,idx] = sort(objs(:,1));
objs = objs(idx,:);
df1 = diff(objs(:,1));
df2 = diff(objs(:,2));
epsilon = 1e-6;
df1(abs(df1) < epsilon) = epsilon;
grad = abs(df2 ./ df1);
grad = [grad; grad(end)];
alpha = 1;
density = 1 ./ (1 + alpha * grad);
Grid.objs = objs;
Grid.density = density;
Grid.archive = Archive;
end
